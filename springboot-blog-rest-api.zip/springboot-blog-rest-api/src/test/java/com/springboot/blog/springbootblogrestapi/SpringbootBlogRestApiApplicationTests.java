package com.springboot.blog.springbootblogrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBlogRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
