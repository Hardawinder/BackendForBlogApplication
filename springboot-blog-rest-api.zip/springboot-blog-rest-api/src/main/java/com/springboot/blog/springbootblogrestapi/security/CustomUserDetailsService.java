package com.springboot.blog.springbootblogrestapi.security;

import java.lang.StackWalker.Option;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.aspectj.weaver.NewConstructorTypeMunger;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.springboot.blog.springbootblogrestapi.entity.User;
import com.springboot.blog.springbootblogrestapi.repository.UserRepository;
import com.springboot.blog.springbootblogrestapi.entity.Role;

@Service
public class CustomUserDetailsService implements UserDetailsService {
	
	UserRepository userRepository;
	
	
	public CustomUserDetailsService(UserRepository userRepository) {
	
		this.userRepository=userRepository;
	}




	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

	    User user=userRepository.findByEmailOrUsername(username,username).orElseThrow(()->new UsernameNotFoundException("What"));
	    System.out.println(mapRolesToAuthories(user.getRoles()));
	    System.out.println("hello"+user.getRoles());
		return new org.springframework.security.core.userdetails.User(user.getEmail(),user.getPassword(),mapRolesToAuthories(user.getRoles()));
	}
	
	private Collection<? extends GrantedAuthority> mapRolesToAuthories(Set<Role> roles){
		

		return roles.stream().map(role->new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
		
	}

}
