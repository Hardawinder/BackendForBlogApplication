package com.springboot.blog.springbootblogrestapi.exception;

import org.springframework.http.HttpStatus;

public class BlogApiException extends RuntimeException {

	private HttpStatus status;
	public HttpStatus getStatus() {
		return status;
	}
	public String getMessage() {
		return message;
	}
	public BlogApiException(HttpStatus status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	private String message;
	
	
}
