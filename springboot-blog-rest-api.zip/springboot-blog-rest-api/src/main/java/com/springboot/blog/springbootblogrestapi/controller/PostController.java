package com.springboot.blog.springbootblogrestapi.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.blog.springbootblogrestapi.service.PostService;
import com.springboot.blog.springbootblogrestapi.utils.AppConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import com.springboot.blog.springbootblogrestapi.payload.PostDto;
import com.springboot.blog.springbootblogrestapi.payload.PostDto2;
import com.springboot.blog.springbootblogrestapi.payload.PostResponse;

@Api(value="CRUD rest api for post resources")
@RestController

public class PostController {
	
	@Autowired
	private PostService postService;

	public PostController(PostService postService) {
		
		this.postService = postService;
	}
	
	@ApiOperation(value="create it here")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping
	public ResponseEntity<PostDto>createPost(@Valid @RequestBody PostDto postDto){
		return new ResponseEntity<>(postService.createPost(postDto),HttpStatus.CREATED);
		
	}
	
	@ApiOperation(value="get by id here")
	@GetMapping(value="/api/posts/{id}",produces="application/vnd.javaguides.v1+json")
	public ResponseEntity<PostDto> getPostById(@PathVariable("id")Long id){
		
		return new ResponseEntity(postService.getPostById(id),HttpStatus.FOUND);
	}
	
	@GetMapping(value="/api/posts/{id}",produces="application/vnd.javaguides.v2+json")
	public ResponseEntity<PostDto2> getPostByV2Id(@PathVariable("id")Long id){
		
		PostDto postDto=postService.getPostById(id);
		List<String> tags=new ArrayList<String>();
		tags.add("twitter");
		tags.add("youtube");
		PostDto2 postDto2=new PostDto2(postDto.getId(),postDto.getTitle(), tags,postDto.getDescription(),postDto.getContent(),
				postDto.getComments());
		return new ResponseEntity<>(postDto2,HttpStatus.OK);
		
	}

	@GetMapping("/api/v1/posts")
	public PostResponse getAllPosts(
			@RequestParam(value="pageNo",defaultValue=AppConstants.DEFAULT_PAGE_NUMBER,required=false)int pageNo,
			@RequestParam(value="pageSize",defaultValue=AppConstants.DEFAULT_PAGE_SIZE,required=false)int pageSize,
			@RequestParam(value="sortBy",defaultValue=AppConstants.DEFAULT_SORT_BY,required=false)String sortBy,
			@RequestParam(value="sortDir",defaultValue=AppConstants.DEFAULT_SORT_DIRECTIOIN,required=false)String sortDir
			
			){
		return postService.getAllPosts(pageNo,pageSize,sortBy,sortDir);
	}
	
	
	@GetMapping("/a")
	public ResponseEntity<List<PostDto>>getAllPosts1(
			
			){
		
		return new ResponseEntity<>(postService.getAllPosts1(),HttpStatus.OK);
	}
	@PutMapping("/api/v1/posts/{id}")
	public ResponseEntity<PostDto> updatePost(@Valid @RequestBody PostDto postDto,@PathVariable(name="id")Long id){
		
		PostDto postResponse=postService.updatePost(postDto, id);
		
		return new ResponseEntity<>(postResponse,HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/api/v1/posts/{id}")
	public ResponseEntity<String>deleteById(@PathVariable(name="id") Long id){
		
		postService.deleteById(id);
		
		return new  ResponseEntity<>(id+" This id is been deleted",HttpStatus.OK);
	}
	

}
