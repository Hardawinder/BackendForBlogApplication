package com.springboot.blog.springbootblogrestapi.payload;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.springboot.blog.springbootblogrestapi.entity.Post;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Api(value="Comment , it is")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommentDto {
	
	@ApiModelProperty(value="comment id")
	private long id;
	
	@NotEmpty
	@Size(min=2,message="should not be empty")
	private String name;
	
	@NotEmpty(message="should not be empty")
	@Email
	private String email;
	
	@NotEmpty
	private String body;


}
