package com.springboot.blog.springbootblogrestapi.payload;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@AllArgsConstructor
public class PostDto2 {
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	private long id;
	
	@NotEmpty
	@Size(min=2,message="minimum length should be 2 characters")
	private String title;
	
	@NotEmpty
	List<String> tags=new ArrayList<>();
	
	@NotEmpty
	@Size(min=10,message="Minimum length should be 10 characters")
	private String description;
	@NotEmpty
	private String content;
	private Set<CommentDto>comments;
	
	
 
}