package com.springboot.blog.springbootblogrestapi.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.springboot.blog.springbootblogrestapi.entity.User;

import antlr.StringUtils;
import ch.qos.logback.core.util.StringCollectionUtil;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	@Autowired
	private CustomUserDetailsService customUserDetailsService;
	
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, 
			HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		//get token from request
		String token=getJWTFromToken(request);
		String uri=request.getRequestURI();
		
		//validate it
		if(uri!=null&& !uri.equalsIgnoreCase("/api/auth/signin") && org.springframework.util.StringUtils.hasText(token)&&jwtTokenProvider.validateToken(token))
			
		{
			
			String Username=jwtTokenProvider.getUsername(token);
			UserDetails user=customUserDetailsService.loadUserByUsername(Username);
			
			UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=new
					UsernamePasswordAuthenticationToken(user,null,user.getAuthorities());
		
			usernamePasswordAuthenticationToken
			.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
		
		
		}
		//retrieve username
		filterChain.doFilter(request, response);
		
		//load user associated with token
		
	}
	
	private String getJWTFromToken(HttpServletRequest request)
	{//Bearer<accessToken>
		
		String bearerToken=request.getHeader("Authorization");
		if(org.springframework.util.StringUtils.hasText(bearerToken)&&bearerToken.startsWith("Bearer "))
		{
			
			String token=bearerToken.substring(7,bearerToken.length());
			return token;
		}
		return null;
	}

	
	
	
	
	
	
	

}
