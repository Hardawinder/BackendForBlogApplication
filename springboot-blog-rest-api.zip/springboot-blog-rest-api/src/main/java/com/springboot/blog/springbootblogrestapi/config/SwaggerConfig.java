package com.springboot.blog.springbootblogrestapi.config;

import java.lang.reflect.Array;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.yaml.snakeyaml.util.ArrayUtils;

import io.jsonwebtoken.lang.Arrays;
import io.jsonwebtoken.lang.Collections;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {
	
	
	public static final String  AUTHORIZATION_HEADER="Authorization";
	
	private ApiKey apiKey() {
		 return new ApiKey(
				
				"JWT"
				,AUTHORIZATION_HEADER,
				"header");
	}

	
	private ApiInfo apiInfo() {
		return new ApiInfo(
				"Spring boot blog rest api",
				"Documentation",
				"1"
				,"Terms of service"
				,new Contact("hello","myName.com","thisIsMyEmail@gmail.com")
				,"Api License",
				"License Url"
				,java.util.Collections.emptyList()
				);
		
	}
	
	@Bean
	public Docket api() {
		return new Docket(DocumentationType.SWAGGER_2).
				apiInfo(apiInfo())
				.securityContexts(java.util.Arrays.asList(securityContext()))
				.securitySchemes(java.util.Arrays.asList(apiKey()))
				.select().apis(RequestHandlerSelectors.any())
				.paths(PathSelectors.any()).build();
		
	}
	
	private SecurityContext securityContext() {
		
		return SecurityContext.builder().securityReferences(defualtAuth()).build();
	}

	private List<SecurityReference> defualtAuth(){
	
		AuthorizationScope authorizationScope=new springfox.documentation.service.AuthorizationScope("global", "accessEverything");
		
		AuthorizationScope[]authorizationScopes=new AuthorizationScope[1];
		authorizationScopes[0]=authorizationScope;
		
		return java.util.Arrays.asList(new SecurityReference("JWT", authorizationScopes));
	}
}
