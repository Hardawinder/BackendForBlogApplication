package com.springboot.blog.springbootblogrestapi.security;

import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

;

@Component
public class JwtTokenProvider {

	@Value("${app.jwt-secret}")
	private String jwtSecret;
	
	@Value("${app.jwt-expiration-milliseconds}")
	private int jwtExpirationInMs;
	
	public String generatedToken(Authentication authentication) {
		String username=authentication.getName();
		Date date=new Date();
		Date expirationDate=new Date(date.getTime()+jwtExpirationInMs);
		
		String token=Jwts.builder().setSubject(username)
				.setIssuedAt(new Date()).setExpiration(expirationDate)
				.signWith(SignatureAlgorithm.HS512,jwtSecret)
				.compact();
		return token;
	}

	
	public String getUsername(String token) {
		
		Claims claim=Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		
		return claim.getSubject();
	}

	public boolean validateToken(String token) {
		try {
			
			Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token);
			return true;
			
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	
}
