package com.springboot.blog.springbootblogrestapi.service.impl;

import java.util.List;import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.springboot.blog.springbootblogrestapi.entity.Post;
import com.springboot.blog.springbootblogrestapi.exception.ResourceNotFoundException;
import com.springboot.blog.springbootblogrestapi.payload.PostDto;
import com.springboot.blog.springbootblogrestapi.payload.PostResponse;
import com.springboot.blog.springbootblogrestapi.repository.PostRepository1;
import com.springboot.blog.springbootblogrestapi.service.PostService;



@Service
public class PostServiceImpl implements PostService{
    
	@Autowired
	private PostRepository1 postRepository1;
	
	private ModelMapper modelMapper;
	

	public PostServiceImpl(PostRepository1 postRepository1,ModelMapper modelMapper
		) {

		this.postRepository1 = postRepository1;
		this.modelMapper=modelMapper;
	}
	
	private Post mapToEntity(PostDto postDto) {
		
		Post post=modelMapper.map(postDto, Post.class);
//		Post post=new Post();
//		
//		post.setTitle(postDto.getTitle());
//		post.setContent(postDto.getDescription());
//		post.setDescription(postDto.getDescription());
		return post;
		
	}



	@Override
	public PostDto createPost(PostDto postDto) {
	
		
		Post post=mapToEntity(postDto);
		
		Post newPost=postRepository1.save(post);
		
	    PostDto postResponse=mapToDTO(newPost);
		
		return postResponse;
	}



	@Override
	public PostResponse getAllPosts(int pageNo,int pageSize,String sortBy,String sorDir) {
		
		Sort sort=sorDir.equalsIgnoreCase(Sort.Direction.ASC.name())?Sort.by(sortBy).ascending()
				:Sort.by(sortBy).descending();
		// TODO Auto-generated method stub
		Pageable pageable=PageRequest.of(pageNo, pageSize,sort);
		
		Page<Post>Pages=postRepository1.findAll(pageable);

		
		List<Post> posts=Pages.getContent();
		List<PostDto> postDto= posts.stream().map(post ->mapToDTO(post)).collect(Collectors.toList());
		PostResponse postResponse=new PostResponse();
		postResponse.setContent(postDto);
		postResponse.setPageNo(Pages.getNumber());
		postResponse.setLast(Pages.isLast());
		postResponse.setPageSize(Pages.getSize());
		postResponse.setTotalElments(Pages.getTotalElements());
		
		
		return postResponse;
	}
	
	
	
	private PostDto mapToDTO(Post post) {
		PostDto postDto=modelMapper.map(post, PostDto.class);
//		PostDto postDto=new PostDto();
//		postDto.setId(post.getId());
//		postDto.setTitle(post.getTitle());
//		postDto.setDescription(post.getDescription());
//		postDto.setContent(post.getContent());
		return postDto;
	}

	@Override
	public PostDto getPostById(Long id) {
		Post post=postRepository1.findById(id).orElseThrow(()->new ResourceNotFoundException("Post","id",id));
		return mapToDTO(post);
	}

	@Override
	public PostDto updatePost(PostDto postDto, Long id) {
		Post post=postRepository1.findById(id).orElseThrow(()->new ResourceNotFoundException("Post","id",id));
		
		post.setTitle(postDto.getTitle());
		post.setDescription(postDto.getDescription());
		post.setContent(postDto.getContent());
		Post updatedPost=postRepository1.save(post);
		return mapToDTO(updatedPost);
	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		Post post=postRepository1.findById(id).orElseThrow(()->new ResourceNotFoundException("Post","id",id));
		
		postRepository1.delete(post);;
		
	}

	@Override
	public List<PostDto> getAllPosts1() {
		List<Post>posts=postRepository1.findAll();
		
		return posts.stream().map(post->mapToDTO(post)).collect(Collectors.toList());
	}
	
	

}
