package com.springboot.blog.springbootblogrestapi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.blog.springbootblogrestapi.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	Optional<User> findByEmail(String email);
	Optional<User>findByEmailOrUsername(String email, String username);
	Optional<User>findByUsername(String username);
	boolean existsByUsername(String Username);
	boolean existsByEmail(String email);

}
