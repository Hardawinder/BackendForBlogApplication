package com.springboot.blog.springbootblogrestapi.payload;

import java.util.Set;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@ApiModel(description="post model information")
@Data

public class PostDto {
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	@ApiModelProperty(value="Blog post id")
	private long id;
	
	@NotEmpty
	@Size(min=2,message="minimum length should be 2 characters")
	private String title;
	
	@NotEmpty
	@Size(min=10,message="Minimum length should be 10 characters")
	private String description;
	@NotEmpty
	private String content;
	private Set<CommentDto>comments;
 
}
