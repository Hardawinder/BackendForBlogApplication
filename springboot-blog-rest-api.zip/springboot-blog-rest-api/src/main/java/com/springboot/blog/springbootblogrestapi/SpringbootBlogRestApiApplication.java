package com.springboot.blog.springbootblogrestapi;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.springboot.blog.springbootblogrestapi.entity.Role;
import com.springboot.blog.springbootblogrestapi.repository.RoleRepository;

@SpringBootApplication
public class SpringbootBlogRestApiApplication implements CommandLineRunner {

	
	@Autowired
	RoleRepository roleRepository;
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootBlogRestApiApplication.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		Role userRole=new Role();
		userRole.setName("USER_ROLE");
		roleRepository.save(userRole);
		
		
		Role adminRole=new Role();
		adminRole.setName("USER_ADMIN");
		roleRepository.save(adminRole);
		
	}

}    