package com.springboot.blog.springbootblogrestapi.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.springboot.blog.springbootblogrestapi.entity.Comment;
import com.springboot.blog.springbootblogrestapi.entity.Post;
import com.springboot.blog.springbootblogrestapi.exception.BlogApiException;
import com.springboot.blog.springbootblogrestapi.exception.ResourceNotFoundException;
import com.springboot.blog.springbootblogrestapi.payload.CommentDto;
import com.springboot.blog.springbootblogrestapi.repository.CommentRepository;
import com.springboot.blog.springbootblogrestapi.repository.PostRepository1;
import com.springboot.blog.springbootblogrestapi.service.CommentService;


@Service
public class CommentServiceImpl implements CommentService{
	
	CommentRepository commentRepository;
	PostRepository1 postRepository1;
	private ModelMapper modelMapper;
	
	public CommentServiceImpl(CommentRepository commentRepository,PostRepository1 postRepository1,ModelMapper modelMapper) {
		this.commentRepository=commentRepository;
		this.postRepository1=postRepository1;
		this.modelMapper=modelMapper;
	}
	
	

	@Override
	public CommentDto createComment(long postId, CommentDto commentDto) {
		
		Comment comment=mapToEntity(commentDto);
		Post post=postRepository1.findById(postId).orElseThrow(()->new ResourceNotFoundException("Post","id",postId));
		comment.setPost(post);
		Comment savedComment=commentRepository.save(comment);
		
		return mapToDto(savedComment);
	}
	
	private CommentDto mapToDto(Comment comment) {
		
		CommentDto commentDto=modelMapper.map(comment, CommentDto.class);
//		CommentDto commentDto=new CommentDto();
//		commentDto.setId(comment.getId());
//		commentDto.setName(comment.getName());
//		commentDto.setEmail(comment.getEmail());
//		commentDto.setBody(comment.getBody());
		return commentDto ;
	}
	private Comment mapToEntity(CommentDto commentDto) {
		Comment comment=modelMapper.map(commentDto, Comment.class);
		
//		commentDto.setId(commentDto.getId());
//		Comment comment=new Comment();
//		comment.setId(commentDto.getId());
//		comment.setName(commentDto.getName());
//		comment.setEmail(commentDto.getEmail());
//		comment.setBody(commentDto.getBody());
		
		return comment ;
	}



	@Override
	public List<CommentDto> getComments(long postId) {
		List<Comment>comments=commentRepository.findByPostId(postId);
		return comments.stream().map(comment->mapToDto(comment)).collect(Collectors.toList());
	}



	@Override
	public CommentDto getCommentById(long postId, long commentId) {
		Post post =postRepository1.findById(postId).orElseThrow(()->new ResourceNotFoundException("Post","post_id",postId));
		
		Comment comment =commentRepository.findById(commentId).orElseThrow(()->new ResourceNotFoundException("Post","post_id",postId));
		
		if(comment.getPost().getId()!=post.getId()) {
			throw new BlogApiException(HttpStatus.BAD_REQUEST, "item cannot be found");
		}
		
		return mapToDto(comment);
	}



	@Override
	public CommentDto updateById(long postId, long commentId, CommentDto commentDto) {
		Post post =postRepository1.findById(postId).orElseThrow(()->new ResourceNotFoundException("Post", "post_id", postId));
		
		Comment comment=commentRepository.findById(commentId).orElseThrow(()->new ResourceNotFoundException("Comment", "CommentId", commentId));
		if(comment.getPost().getId()!=post.getId()) {
		   throw new BlogApiException(HttpStatus.BAD_REQUEST, "Comment associated with particular post is not found");
		   
		}
		comment.setBody(commentDto.getBody());
		comment.setEmail(commentDto.getEmail());
		comment.setName(commentDto.getName());
		Comment updated=commentRepository.save(comment);
	
		
		
		return mapToDto(comment);
	}



	@Override
	public void deleteBy(long postId, long commentId) {
Post post =postRepository1.findById(postId).orElseThrow(()->new ResourceNotFoundException("Post", "post_id", postId));
		
		Comment comment=commentRepository.findById(commentId).orElseThrow(()->new ResourceNotFoundException("Comment", "CommentId", commentId));
		if(comment.getPost().getId()!=post.getId()) {
		   throw new BlogApiException(HttpStatus.BAD_REQUEST, "Comment associated with particular post is not found");
		   
		}
		commentRepository.deleteById(commentId);
		
		
	}
	

}
