package com.springboot.blog.springbootblogrestapi.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.blog.springbootblogrestapi.payload.CommentDto;
import com.springboot.blog.springbootblogrestapi.service.impl.CommentServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value="CRUD rest api for comments")
@RestController
@RequestMapping("/api/v1")
public class CommentController {
	
     CommentServiceImpl commentServiceImpl;
     
     public CommentController(CommentServiceImpl commentServiceImpl) {
    	 
    	 this.commentServiceImpl=commentServiceImpl;
    	     }
     
     
     @ApiOperation(value="create a new comment for a post")
        @PostMapping("/posts/{postId}/comment")
       public ResponseEntity<CommentDto> createComment(@PathVariable(name="postId")long postId,
    		  @Valid @RequestBody CommentDto commentDto
    		   ) {
    	   
    	   System.out.println(postId);
    	   return new ResponseEntity<>(commentServiceImpl.createComment(postId, commentDto),HttpStatus.OK);
       }
       
       @GetMapping("/posts/{postId}/comment")
       public List<CommentDto> getByPostId(@PathVariable(name="postId")Long postId){
    	  
    	  return commentServiceImpl.getComments(postId); 
       }
       @GetMapping("/posts/{postId}/comment/{commentId}")
       public CommentDto getByCommentId(@PathVariable(name="postId")Long postId,
    		   @PathVariable(name="commentId")Long commentId
    		   ){
    	  
    	  return commentServiceImpl.getCommentById(postId,commentId); 
       }
       
       @PutMapping("/posts/{postId}/comment/{commentId}")
       public ResponseEntity<CommentDto> updateComment(@PathVariable(name="postId")Long postId,
    		   @PathVariable(name="commentId")Long commentId,
    		  @Valid @RequestBody CommentDto commentDto
    		   ){
    	  CommentDto updatedDto=commentServiceImpl.updateById(postId, commentId, commentDto);
    	  return new ResponseEntity<>(updatedDto,HttpStatus.ACCEPTED); 
       }
       @DeleteMapping("/posts/{postId}/comment/{commentId}")
       public ResponseEntity<String> deleteComment(@PathVariable(name="postId")Long postId,
    		   @PathVariable(name="commentId")Long commentId
    		   ){
    	  commentServiceImpl.deleteBy(postId, commentId);
    	  return new ResponseEntity<>("This comment is been deleleted",HttpStatus.ACCEPTED); 
       }
       
}

