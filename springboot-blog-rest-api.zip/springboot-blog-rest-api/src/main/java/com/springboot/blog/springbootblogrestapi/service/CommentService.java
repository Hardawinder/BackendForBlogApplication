package com.springboot.blog.springbootblogrestapi.service;

import java.util.List;

import com.springboot.blog.springbootblogrestapi.entity.Comment;
import com.springboot.blog.springbootblogrestapi.payload.CommentDto;

public interface CommentService {
	
	CommentDto createComment(long postId,CommentDto commentDto);
	List<CommentDto> getComments(long postId);
	CommentDto getCommentById(long postId, long commentId);
	CommentDto updateById(long postId,long commentId,CommentDto commentDto);
	void deleteBy(long postId, long commentId);

}
